/*  Aufgabe: Abschlussaufgabe
    Name: Alena Hurst
    Matrikel: 257742
    Datum: 29.07.18
    
    Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.*/

namespace Dot {
    export class SuperClass {
        x: number;
        y: number;

        constructor() {
            // ohne Inhalt    
        }
        
        draw(): void {
            // ohne Inhalt    
        }

        move(): void {
            // ohne Inhalt    
        }
    } // class 
} // namespace