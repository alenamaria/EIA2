/*  Aufgabe: Abschlussaufgabe
    Name: Alena Hurst
    Matrikel: 257742
    Datum: 29.07.18
    
    Hiermit versichere ich, dass ich diesen Code selbst geschrieben habe. Er wurde nicht kopiert und auch nicht diktiert.*/
var Dot;
(function (Dot) {
    class SuperClass {
        constructor() {
            // ohne Inhalt    
        }
        draw() {
            // ohne Inhalt    
        }
        move() {
            // ohne Inhalt    
        }
    }
    Dot.SuperClass = SuperClass; // class 
})(Dot || (Dot = {})); // namespace
//# sourceMappingURL=SuperClass.js.map